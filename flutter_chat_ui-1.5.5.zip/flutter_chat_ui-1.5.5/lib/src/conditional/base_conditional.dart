import 'conditional.dart';

/// The abstract base class for a conditional import feature.
abstract class BaseConditional implements Conditional {}
