---
id: installation
title: Installation
---

Add `flutter_chat_ui` to your package's `pubspec.yaml` file. Check current version on [pub.dev](https://pub.dev/packages/flutter_chat_ui/install).
